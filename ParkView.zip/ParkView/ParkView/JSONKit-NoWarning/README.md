# JSONKit

Please refer to the original documentation.  
This fork fix some warning raised with xcode5 and 64bit.
